"""Базовый векторный поиск: чанкинг, эмбеддинги, индекс, поиск.

Модуль вынесен из ноутбука занятия 2, потому что механика векторного поиска
разбирается в отдельном интенсиве. Здесь он импортируется как готовый
инструмент — так же, как в реальном проекте вы импортируете библиотеку,
а не переписываете косинусное сходство заново.

Что внутри:
    SourceDocument, DocumentChunk  — контейнеры документа и фрагмента
    fixed_window_split             — антипример: резать по символам
    paragraph_split                — рабочая стратегия: резать по абзацам
    embed_texts                    — векторизация батчами с учётом расхода
    normalize_vector               — приведение к единичной длине
    SearchHit, search_corpus       — поиск по косинусному сходству

Использование:
    from retrieval_utils import paragraph_split, embed_texts, search_corpus

Подробные пояснения — в файлах 01-chunking.md, 02-embeddings.md,
03-index-and-search.md рядом с этим модулем.
"""

from dataclasses import dataclass
from typing import Any, Callable

import numpy as np

@dataclass(frozen=True)
class SourceDocument:
    source_id: str
    title: str
    version: str
    text: str

@dataclass(frozen=True)
class DocumentChunk:
    chunk_id: str
    source_id: str
    source_title: str
    source_version: str
    position: int
    text: str

    @property
    def characters(self) -> int:
        return len(self.text)

def fixed_window_split(
    text: str,
    chunk_size: int,
    overlap: int,
) -> list[str]:
    if chunk_size <= 0:
        raise ValueError("chunk_size должен быть положительным")
    if not 0 <= overlap < chunk_size:
        raise ValueError(
            "overlap должен быть в диапазоне [0, chunk_size)"
        )

    step = chunk_size - overlap
    return [
        text[start : start + chunk_size]
        for start in range(0, len(text), step)
        if text[start : start + chunk_size].strip()
    ]

def paragraph_split(
    document: SourceDocument,
    *,
    max_chars: int = 700,
    overlap_chars: int = 160,
) -> list[DocumentChunk]:
    if max_chars <= 0:
        raise ValueError("max_chars должен быть положительным")
    if not 0 <= overlap_chars < max_chars:
        raise ValueError(
            "overlap_chars должен быть меньше max_chars"
        )

    paragraphs = [
        paragraph.strip()
        for paragraph in document.text.split("\n\n")
        if paragraph.strip()
    ]

    groups: list[list[str]] = []
    current: list[str] = []

    for paragraph in paragraphs:
        candidate = "\n\n".join([*current, paragraph])

        if current and len(candidate) > max_chars:
            groups.append(current)

            overlap_group: list[str] = []
            overlap_size = 0

            for previous in reversed(current):
                additional = len(previous) + (
                    2 if overlap_group else 0
                )
                if overlap_size + additional > overlap_chars:
                    break
                overlap_group.insert(0, previous)
                overlap_size += additional

            current = overlap_group

        current.append(paragraph)

    if current:
        groups.append(current)

    return [
        DocumentChunk(
            chunk_id=(
                f"{document.source_id}_c{position:02d}"
            ),
            source_id=document.source_id,
            source_title=document.title,
            source_version=document.version,
            position=position,
            text="\n\n".join(group),
        )
        for position, group in enumerate(groups, start=1)
    ]

def _to_dict(value: Any) -> dict:
    """Приводит объект SDK к словарю, не завися от версии Pydantic."""
    if value is None:
        return {}
    for attr in ("model_dump", "dict"):
        method = getattr(value, attr, None)
        if callable(method):
            return method()
    return dict(value) if isinstance(value, dict) else {}


def embedding_prompt_tokens(response: Any) -> int:
    total = 0

    for item in getattr(response, "data", []):
        usage = _to_dict(getattr(item, "usage", None))
        total += int(
            usage.get("prompt_tokens") or 0
        )

    return total


def embed_texts(
    texts: list[str],
    client: Any,
    *,
    model: str = "EmbeddingsGigaR",
    batch_size: int = 16,
) -> tuple[list[np.ndarray], int]:
    """Векторизует тексты батчами. Возвращает векторы и расход токенов."""
    if not texts:
        return [], 0

    vectors: list[np.ndarray] = []
    prompt_tokens = 0

    for start in range(0, len(texts), batch_size):
        batch = texts[start : start + batch_size]
        response = client.embeddings(
            batch,
            model=model,
        )

        ordered_items = sorted(
            response.data,
            key=lambda item: item.index,
        )

        vectors.extend(
            np.asarray(
                item.embedding,
                dtype=np.float32,
            )
            for item in ordered_items
        )

        prompt_tokens += embedding_prompt_tokens(
            response
        )

    if len(vectors) != len(texts):
        raise RuntimeError(
            "Число эмбеддингов не совпало с числом текстов"
        )

    return vectors, prompt_tokens

def normalize_vector(vector: np.ndarray) -> np.ndarray:
    norm = np.linalg.norm(vector)

    if norm == 0:
        raise ValueError(
            "Нельзя нормализовать нулевой вектор"
        )

    return vector / norm


def cosine_scores(
    query_vector: np.ndarray,
) -> np.ndarray:
    normalized_query = normalize_vector(
        query_vector.astype(np.float32)
    )

    return (
        NORMALIZED_EMBEDDING_MATRIX
        @ normalized_query
    )

@dataclass
class SearchHit:
    """Найденный фрагмент и оценки близости по каждому запросу.

    Словарь, а не одно число: при разбиении вопроса на подвопросы один
    фрагмент может найтись сразу по нескольким из них.
    """

    chunk: DocumentChunk
    scores_by_query: dict

    @property
    def score(self) -> float:
        return max(self.scores_by_query.values())

    @property
    def matched_queries(self) -> list:
        return list(self.scores_by_query)


DEFAULT_RETRIEVAL_INSTRUCTION = (
    "Дан вопрос, необходимо найти абзац, "
    "наиболее релевантный по смыслу\n"
)


def prepare_retrieval_query(
    question: str,
    instruction: str = DEFAULT_RETRIEVAL_INSTRUCTION,
) -> str:
    """Готовит текст запроса для векторизации.

    Инструкция добавляется только к запросу — к документам не добавляется.
    """
    cleaned = " ".join(question.split())
    if not cleaned:
        raise ValueError("Вопрос не должен быть пустым")
    return f"{instruction}вопрос: {cleaned}"


class VectorIndex:
    """Индекс фрагментов: матрица нормализованных векторов плюс метаданные.

    Хранит всё, что нужно для поиска, и не зависит от глобальных переменных.
    Для тысяч фрагментов матричного умножения достаточно; когда фрагментов
    станут сотни тысяч или понадобится фильтрация по метаданным, на это место
    ставят векторную базу — интерфейс поиска при этом не меняется.
    """

    def __init__(
        self,
        chunks: list,
        matrix: np.ndarray,
        client: Any,
        *,
        model: str = "EmbeddingsGigaR",
        instruction: str = DEFAULT_RETRIEVAL_INSTRUCTION,
    ) -> None:
        if len(chunks) != matrix.shape[0]:
            raise ValueError(
                f"Фрагментов {len(chunks)}, векторов {matrix.shape[0]} — не совпадает"
            )

        self.chunks = chunks
        self.matrix = matrix.astype(np.float32)
        self.matrix /= np.linalg.norm(self.matrix, axis=1, keepdims=True)
        self.client = client
        self.model = model
        self.instruction = instruction

    def __len__(self) -> int:
        return len(self.chunks)

    def embed_query(self, question: str) -> tuple[np.ndarray, int]:
        """Вектор запроса. Инструкция добавляется только к запросу."""
        vectors, tokens = embed_texts(
            [prepare_retrieval_query(question, self.instruction)],
            self.client,
            model=self.model,
        )
        return normalize_vector(vectors[0]), tokens

    def search_by_vector(
        self,
        vector: np.ndarray,
        *,
        matched_query: str = "",
        top_k: int = 5,
        min_score: float | None = None,
    ) -> list[SearchHit]:
        scores = self.matrix @ vector
        order = np.argsort(-scores)[: max(top_k * 4, top_k)]

        hits = []
        for idx in order:
            score = float(scores[idx])
            if min_score is not None and score < min_score:
                continue
            hits.append(
                SearchHit(
                    chunk=self.chunks[idx],
                    scores_by_query={matched_query: score},
                )
            )
            if len(hits) >= top_k:
                break

        return hits

    def search(
        self,
        question: str,
        *,
        top_k: int = 5,
        min_score: float | None = None,
    ) -> tuple[list[SearchHit], int]:
        """Поиск по вопросу. Возвращает результаты и расход токенов запроса."""
        vector, tokens = self.embed_query(question)
        hits = self.search_by_vector(
            vector, matched_query=question, top_k=top_k, min_score=min_score
        )
        return hits, tokens
